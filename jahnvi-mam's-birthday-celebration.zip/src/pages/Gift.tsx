import { motion } from 'motion/react';
import { Gift as GiftIcon, Sparkles, RotateCcw } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Gift() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="page-transition flex flex-col items-center justify-center text-center min-h-[80vh]"
    >
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{
          type: "spring",
          stiffness: 260,
          damping: 20,
          delay: 0.2
        }}
        className="w-32 h-32 bg-rose-100 rounded-full flex items-center justify-center mb-12 relative"
      >
        <GiftIcon size={48} className="text-rose-500" />
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
          className="absolute inset-0 border-2 border-dashed border-rose-300 rounded-full"
        />
      </motion.div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
      >
        <h2 className="serif text-6xl mb-8">A Small Surprise...</h2>
        <div className="glass p-10 rounded-[40px] max-w-xl mx-auto shadow-xl relative overflow-hidden mb-12">
          <Sparkles className="absolute top-4 right-4 text-rose-300" />
          <Sparkles className="absolute bottom-4 left-4 text-rose-300" />

          <p className="serif text-4xl text-rose-600 font-medium mb-4">
            Gift Arriving Ur Way at 7pm
          </p>
          <p className="text-stone-500 italic">
            Hope this brings a smile to your face, Jahnvi Ma'am.
          </p>
        </div>
      </motion.div>

      <Link to="/">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-2 text-stone-400 hover:text-rose-500 transition-colors text-sm uppercase tracking-widest font-semibold"
        >
          <RotateCcw size={16} /> Start Over
        </motion.button>
      </Link>

      <motion.footer
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="mt-24 border-t border-rose-100 pt-8 w-full max-w-xs"
      >
        <p className="text-xs uppercase tracking-[0.3em] text-stone-400 mb-2">Developed with Love by</p>
        <p className="serif text-2xl text-stone-700">Harsh Bansal</p>
      </motion.footer>
    </motion.div>
  );
}
