import { motion } from 'motion/react';
import { Quote, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Wishes() {
  const mainWish = {
    text: "Happy Birthday, Ma’am. 🎉 You’re an amazing teacher and someone I truly admire a lot. Your kindness and the way you teach make every class special. I wish you a beautiful birthday and a year full of happiness. And honestly… you’re not one of my favorite but the most famous person. 🌸",
    author: "Harsh Bansal"
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="page-transition max-w-4xl mx-auto flex flex-col items-center"
    >
      <div className="text-center mb-16">
        <h2 className="serif text-5xl mb-4">A Special Message</h2>
        <div className="h-px w-24 bg-rose-200 mx-auto" />
      </div>

      <div className="grid gap-8 w-full mb-16">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="glass p-12 rounded-[40px] relative overflow-hidden group shadow-xl border-rose-100"
        >
          <Quote className="absolute -top-4 -left-4 w-32 h-32 text-rose-50 -z-10" />
          <p className="serif text-3xl md:text-4xl mb-8 text-stone-800 leading-relaxed italic text-center">
            {mainWish.text}
          </p>
          <div className="flex flex-col items-center">
            <div className="h-px w-12 bg-rose-300 mb-4" />
            <p className="text-sm uppercase tracking-[0.4em] text-rose-500 font-bold">
              {mainWish.author}
            </p>
          </div>
        </motion.div>
      </div>

      <Link to="/gift">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-2 bg-rose-500 text-white px-8 py-4 rounded-full font-medium shadow-lg shadow-rose-200 hover:bg-rose-600 transition-colors mb-12"
        >
          See the Surprise <ArrowRight size={20} />
        </motion.button>
      </Link>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="text-center"
      >
        <p className="serif text-2xl italic text-stone-400">
          "Teaching is the greatest act of optimism."
        </p>
      </motion.div>
    </motion.div>
  );
}
