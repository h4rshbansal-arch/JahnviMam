import { motion } from 'motion/react';
import confetti from 'canvas-confetti';
import { useEffect } from 'react';
import { Heart, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Home() {
  useEffect(() => {
    const duration = 3 * 1000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

    const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min;

    const interval: any = setInterval(function() {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      const particleCount = 50 * (timeLeft / duration);
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } });
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } });
    }, 250);

    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="page-transition flex flex-col items-center justify-center text-center"
    >
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="mb-8"
      >
        <span className="text-rose-500 uppercase tracking-[0.3em] text-sm font-semibold">Celebrating</span>
      </motion.div>

      <motion.h1
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="serif text-7xl md:text-9xl mb-6 leading-tight"
      >
        Jahnvi <br /> <span className="italic">Ma’am</span>
      </motion.h1>

      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="relative w-64 h-80 md:w-80 md:h-[450px] rounded-full overflow-hidden border-8 border-white shadow-2xl mb-12"
      >
        <img
          src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=1000&auto=format&fit=crop"
          alt="Jahnvi Ma'am"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-rose-500/20 to-transparent" />
      </motion.div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.8 }}
        className="max-w-md"
      >
        <p className="serif text-2xl italic text-stone-600 mb-8">
          "Celebrating the most admired teacher."
        </p>
        <div className="flex items-center justify-center gap-2 text-rose-400 mb-12">
          <Heart size={20} fill="currentColor" />
          <Heart size={20} fill="currentColor" />
          <Heart size={20} fill="currentColor" />
        </div>

        <Link to="/wishes">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-2 bg-rose-500 text-white px-8 py-4 rounded-full font-medium shadow-lg shadow-rose-200 hover:bg-rose-600 transition-colors"
          >
            Read My Message <ArrowRight size={20} />
          </motion.button>
        </Link>
      </motion.div>
    </motion.div>
  );
}
