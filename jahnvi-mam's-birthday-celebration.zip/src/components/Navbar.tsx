import { Link, useLocation } from 'react-router-dom';
import { motion } from 'motion/react';

export default function Navbar() {
  const location = useLocation();

  const links = [
    { path: '/', label: 'Home' },
    { path: '/wishes', label: 'Wishes' },
    { path: '/gift', label: 'The Gift' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 flex justify-center p-6">
      <div className="glass rounded-full px-6 py-3 flex gap-8 items-center shadow-sm">
        {links.map((link) => (
          <Link
            key={link.path}
            to={link.path}
            className={`relative text-sm uppercase tracking-widest font-medium transition-colors hover:text-rose-500 ${
              location.pathname === link.path ? 'text-rose-600' : 'text-stone-600'
            }`}
          >
            {link.label}
            {location.pathname === link.path && (
              <motion.div
                layoutId="nav-underline"
                className="absolute -bottom-1 left-0 right-0 h-px bg-rose-600"
              />
            )}
          </Link>
        ))}
      </div>
    </nav>
  );
}
